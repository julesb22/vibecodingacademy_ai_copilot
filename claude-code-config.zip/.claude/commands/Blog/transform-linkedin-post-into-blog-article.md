---
description: Write a blog article for Vibe Coding Academy's website based on the content of a Linkedin post I'll share as argument. I'll also provide the keyword to target
argument-hint: [content of the article] [target keyword]
---


/agents use linkedin-blog-converter

Write a SEO-optimized article for Vibe Coding Academy's website based on the following Linkedin post: $1

Optimize the content of this article based on the keyword to target: $2

To write the article, you should leverage the following agent, where all instructions about how to transform the content of the linkedin post is explained `linkedin-blog-converter.md`