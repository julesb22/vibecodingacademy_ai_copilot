---
description: Write an article based on brainstorming notes using LinkedIn engagement writer agent
argument-hint: [brainstorming notes or topic]
---

/agents use linkedin-engagement-writer

Write the following article based on the following brainstorming I just had around the content of this article: $ARGUMENTS

To write the article, you should leverage the agents that we have set-up in this project, which is called `linkedin-engagement-writer.md`