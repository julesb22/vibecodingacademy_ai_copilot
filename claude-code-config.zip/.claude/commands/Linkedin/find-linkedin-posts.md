---
description: Find a list of 5 Linkedin posts related to Vibe Coding Academy's business
argument-hint: 
---

/agents use linkedin-posts-finder

Find out 5 Linkedin posts using `linkedin-posts-finder.md` 