---
description: Refine the draft of an article based on brainstorming notes using LinkedIn article refiner agent
argument-hint: [Draft] [Brainstorming Notes]
---

/agents use linkedin-article-refiner

Refine the content of this draft $1 based on the following brainstorming I just around the content of this article: $2

To write the article, you should leverage the agents that we have set-up in this project, which is called `linkedin-article-refiner.md`