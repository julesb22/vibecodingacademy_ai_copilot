---
description: Find 5 ideas of topics for Vibe Coding Academy's newsletter using /agents newsletter-topic-generator
argument-hint: 
---

/agents use newsletter-topic-generator to come-up with the five ideas of topics for Vibe Coding Academy's newsletter

