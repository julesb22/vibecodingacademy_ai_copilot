---
description: Provide constructive critics on the idea that I'm sharing, and help me solve the limitations and risks you're bubbling up on these ideas
---


/agents use ideas-hard-critizer

Please provide constructive feedback on my idea and help me address any limitations or risks you identify using the following agent `ideas-hard-critizer.md` 
