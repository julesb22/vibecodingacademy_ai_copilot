---
description: Come-up with 5 new product ideas for Vibe Coding Academy
argument-hint: [Input (customers feedback, ideas, specific outcome,...)]
---

/agents use product-ideas

Find out 5 product ideas using `product-ideas.md` 
