---
description: Come-up with a list of 3 growth experiments to improve AARRR (Acquisition / Activation / Revenue / Retention / Referral)
---


/agents use growth-experiment-generator

Come-up with a list of 3 growth experiments to improve AARRR (Acquisition / Activation / Revenue / Retention / Referral)
